<?php

$conn = mysqli_connect('127.0.0.1','root','root','sammy');



	$qry = "SELECT * FROM admin";
	$rn = mysqli_query($conn, $qry);

	while($data = mysqli_fetch_assoc($rn)){
	
	
		echo "

			<table>
			<tr>
			<th>Name</th>
			<th>Username</th>
			</tr>

			<tr>
			<td>".$data['Username']."</td>
			<td>".$data['Password']."</td>
			</tr>

			</table>
		";








	}

	



?>
