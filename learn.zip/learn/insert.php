<?php

$conn = mysqli_connect('127.0.0.1','root','root','sammy');


if($_SERVER["REQUEST_METHOD"] == "POST"){

	//$name = $_POST['name'];

	$username = $_POST['Username'];

	$pass = $_POST['Password'];


	$qery = "INSERT INTO admin (Username,Password) Values ('$username','$pass')";

	if(mysqli_query($conn, $qery)){
		echo "Data INserted Successfully";
	}else{
		echo "SomeThing Wrong!!!";
	}

}



?>
