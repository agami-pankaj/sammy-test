
	<input type="text" id="name" name="Name" placeholder="name"><br>
	<input type="text" id="uname" name="Username" placeholder="username"><br>
	<input type="password" id="pass" name="Password" placeholder="password"><br>


	<input type="button" id="sub" value="Insert">

<button id="btn">ck-a</button>


	<script>


$('#sub').click(function(){
	//var data = $('#sub-form').serialize();
	   $.ajax({
           type: "post",
           url: "insert.php",
           data: {
           		Username: $('#name').val(),
           		Password: $('#uname').val()
           },
           success: function(response, status){
           	swal("Good job!", response, "success");
           	$('#name').val('');
           }
        });

});



/*
$('#btn').click(function(){

	alert('Hello');

});
*/
</script>

