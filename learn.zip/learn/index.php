<!DOCTYPE html>
<html>
<head>
<base src="127.0.0.1/learn">
	<title>Index Page</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sammy.js/0.7.6/sammy.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<style type="text/css">
	
.frm{
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	width: 40%;
	box-shadow: 1px 1px 10px 1px solid black;
}


</style>


</head>
<body>

<div id="box">
	



</div>
<hr>
<a href="#/insert-form"><button id="ins">Sign up</button></a><a href="#/display"><button id="dis">Display</button></a><a href="#/"><button id="dis">Index</button></a>

<button id="btn">ck</button>

<script>
	
(function(){

	var myApp = Sammy('body');

	$(document).ready(function(){
		myApp.run('#/');
	});



	myApp.get('#/', function(context){

		$('#box').html('Index Page');
		//alert(context.params.id);

	});


	myApp.get('#/insert-form', function(){

		$('#box').load('form.php');

	});

	myApp.get('#/display', function(){

		$.ajax({
			type: "GET",
			url: "display.php",
			data: { get_param: 'value'},
			success: function(data){
				var names = data;
				$('#box').html(names);
				
			}
		})

	});

	myApp.get('#/insert-data', function(){

	});



}) ();





</script>


</body>
</html>