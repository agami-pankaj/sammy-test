<?php

$conn = mysqli_connect('127.0.0.1','root','','qeryajx');

/*
if($_SERVER["REQUEST_METHOD"] == "POST"){

	$name = $_POST['name'];

	$username = $_POST['username'];

	$pass = $_POST['password'];

	$qery = "INSERT INTO user (name,username,password) VALUES ('$name','$username','$pass')";

	if(mysqli_query($conn, $qery)){
		echo "Data Inserted";
	}else{
		echo "Faild!";
	}

}
*/


	$qry = "SELECT * FROM user";
	$rn = mysqli_query($conn, $qry);

	while($data = mysqli_fetch_array($rn)){
	
		print_r($data);

	}












?>
